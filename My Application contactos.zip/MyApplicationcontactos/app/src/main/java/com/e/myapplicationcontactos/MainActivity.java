package com.e.myapplicationcontactos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity<nombreContactos> extends AppCompatActivity {

    ListView lvContactos;
    ArrayList<Contacto> contactos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvContactos = (ListView) findViewById(R.id.lvContactos);
        contactos = new ArrayList<>();
        contactos.add(new Contacto("Edixo", "Jiménez", 64150795, "Punta Pacifica"));
        contactos.add(new Contacto("Andrea", "Urdaneta", 63456789, "San Francisco"));
        contactos.add(new Contacto("Juan", "Fuenmayor", 69387206, "Costa del Este"));
        contactos.add(new Contacto("Elide", "Garcia", 69874532, "El Cangrejo"));
        contactos.add(new Contacto("Sofia", "Duarte", 68987867, "El Carmen"));

        ArrayList<String> nombreContactos = new ArrayList<>();

        for (Contacto contacto : contactos) {
            nombreContactos.add(contacto.getNombre() + " " + contacto.getApellido());
        }
        lvContactos.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, nombreContactos));
        lvContactos.setOnClickListener(new AdapterView.OnItemClickListener() {
            @Override
                    public void onItemClick(AdapterView<?>) AdapterView, View, int i, long l){
                        getIntent()= onNewIntent(MainActivity.this,detalleContacto.class);
                        getIntent().putExtra("NAMECONTACTO",contactos.get().getNombre();
                        getIntent().putExtra("APELLIDOCONTACTO",contactos.get().getApellido();
                        getIntent().putExtra("TELEFONOCONTACTO",contactos.get().getTelefono();
                         getIntent().putExtra("TELEFONOCONTACTO",contactos.get().getTelefono();

                startActivities(getIntent());
            }
        });

    }
}